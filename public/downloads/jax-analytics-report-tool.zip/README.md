# Excel Data Cleanup & Reporting Tool — prototype

## Revised workflow matching the reference outputs

`workflow_tool.py` produces four files: Cleaned Master.xlsx (with removed duplicates and quality findings), Grouped Records.xlsx (complete records in separate category worksheets), Yearly Comparison.xlsx, and Results Summary.docx.

```
python workflow_tool.py sample_sales.csv --category Category --amount Amount --date Date --id RecordID --deduplicate --output reports
```

This version accepts choices through command-line options. It currently supports one category grouping per run, and annual totals from a single date/amount pair. Configurable numerical bands, several grouping schemes in one run, and wide annual columns such as “2024 Gifts” are not implemented yet. It does not reproduce donor-specific rules. Missing yearly observations remain blank; year-over-year changes are undefined when the prior year is missing or zero. Each run creates its own folder.

The earlier `report_tool.py` guided prototype remains included for comparison. Start with `workflow_tool.py` for the revised deliverables. Generated content has calculation checks; visual review in Excel and Word is still pending.

An independent, general-purpose implementation for Jax's Analytics. No employer-specific source code or records are included.

## Run

Install Python 3.11 or later, then open a terminal in this folder:

```
python -m pip install -r requirements.txt
python report_tool.py
```

Choose a source file and output folder using the file pickers. Worksheet and column choices are entered in the terminal. This first version is a guided script, not a packaged desktop app.

Try the included fictional data:

```
python report_tool.py sample_sales.csv --category Category --amount Amount --date Date --id RecordID --output reports
```

Add `--deduplicate` only when repeated IDs represent duplicate records rather than legitimate separate transactions. It keeps the first nonblank ID, even if a later record is more complete. Blank IDs are retained and flagged.

## Inputs and output

Accepts .xlsx and UTF-8 CSV with a unique, nonblank header row. Choose one category and amount column, optionally a date and ID column. Use ISO dates (YYYY-MM-DD) or Excel date cells. Amounts use a decimal point and optional thousands commas, dollar sign, and parentheses for negatives. Use one currency/unit per run; no exchange conversion is performed. XLSX formulas use their last Excel-saved values: recalculate and save the source in Excel first.

Reports include a summary, monthly totals and chart, data-quality findings, prepared rows, and original source values with source row numbers. Invalid amounts stay visible but do not contribute to totals. Invalid dates do not contribute to monthly totals, so monthly and category totals may differ. Missing categories become Uncategorized. Original files are never modified. Each report receives a unique filename.

Outputs are static snapshots. Rerun after changing the source; editing the report does not refresh summaries. The source copy preserves values, not formatting or formulas. Source text is exported as literal text to prevent it becoming executable Excel formulas. Reports can contain all original source values: keep reports private when using real client data.

The sample includes intentional errors and duplicate IDs. It is entirely fictional. No performance or client-outcome claims are made.
