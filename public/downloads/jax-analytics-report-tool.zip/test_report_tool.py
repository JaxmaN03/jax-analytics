import tempfile
from contextlib import contextmanager

@contextmanager
def test_directory():
    # Keep scratch artifacts for inspection when sandbox deletion is restricted.
    yield str(Path(__file__).resolve().parents[2] / 'work' / 'report-tests')

import unittest
from decimal import Decimal
from pathlib import Path
from openpyxl import load_workbook
from report_tool import analyze, create_report, read_rows


class ReportingTests(unittest.TestCase):
    def test_sample_totals_and_optional_duplicates(self):
        _, rows = read_rows(Path(__file__).with_name('sample_sales.csv'))
        kept = analyze(rows, 'Category', 'Amount', 'Date', 'RecordID')
        removed = analyze(rows, 'Category', 'Amount', 'Date', 'RecordID', True)
        self.assertEqual(kept['source'], 20)
        self.assertEqual(kept['duplicates'], 1)
        self.assertEqual(kept['invalid_amounts'], 1)
        self.assertEqual(kept['invalid_dates'], 1)
        self.assertEqual(sum(kept['categories'].values()), Decimal('15625'))
        self.assertEqual(sum(removed['categories'].values()), Decimal('13625'))
        self.assertEqual(sum(removed['months'].values()), Decimal('13575'))

    def test_export_preserves_input_and_literal_text(self):
        with test_directory() as directory:
            root = Path(directory)
            source = root / 'input.csv'
            content = 'ID,Group,Value,Date\n001,=1+1,0,2026-01-01\n002,A,-5,2026-03-01\n'
            source.write_text(content)
            target, result = create_report(source, root, 'Group', 'Value', 'Date', 'ID')
            second, _ = create_report(source, root, 'Group', 'Value', 'Date', 'ID')
            self.assertNotEqual(target, second)
            self.assertEqual(source.read_text(), content)
            book = load_workbook(target)
            self.assertEqual(book['Source Data']['B2'].value, '001')
            self.assertEqual(book['Source Data']['C2'].data_type, 's')
            self.assertEqual(book['Monthly']['A3'].value, '2026-02')
            self.assertEqual(book['Monthly']['B3'].value, 0)
            self.assertEqual(book['Summary']['B11'].value, -5)
            book.close()

    def test_bad_columns_fail_clearly(self):
        with test_directory() as directory:
            with self.assertRaisesRegex(ValueError, 'Column not found'):
                create_report(Path(__file__).with_name('sample_sales.csv'), Path(directory), 'Absent', 'Amount')


if __name__ == '__main__':
    unittest.main()



