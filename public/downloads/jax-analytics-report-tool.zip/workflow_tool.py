"""Create a cleaned master, grouped records, annual comparisons and Word summary.

Example: python workflow_tool.py sample_sales.csv --category Category --amount Amount
         --date Date --id RecordID --deduplicate --output reports
"""
import argparse
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
import re

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from report_tool import read_rows, amount, parse_date, safe_append


def format_sheet(ws):
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    ws.sheet_view.showGridLines = False
    for cell in ws[1]:
        cell.fill = PatternFill('solid', fgColor='152A40')
        cell.font = Font(color='FFFFFF', bold=True)
    ws.row_dimensions[1].height = 26
    for column in ws.columns:
        ws.column_dimensions[column[0].column_letter].width = min(48, max(18, max(len(str(c.value or '')) for c in column)+2))


def sheet_name(label, used):
    base = re.sub(r'[\\/*?:\[\]]', '_', str(label)).strip(" '")[:31] or 'Uncategorized'
    candidate, suffix = base, 1
    while candidate.casefold() in used:
        suffix += 1
        candidate = base[:31-len(str(suffix))-1] + '_' + str(suffix)
    used.add(candidate.casefold())
    return candidate


def build_bundle(source, output, category, money, date_column, id_column=None,
                 deduplicate=False, sheet=None):
    headers, original = read_rows(source, sheet)
    for name in (category, money, date_column, id_column):
        if name and name not in headers:
            raise ValueError(f'Column not found: {name}')
    if deduplicate and not id_column:
        raise ValueError('An ID column is required for duplicate removal.')
    if len(headers) >= 16384:
        raise ValueError('Too many columns to add source row references.')
    retained, removed, seen = [], [], set()
    duplicate_count = 0
    for number, row in original:
        raw_id = row.get(id_column) if id_column else None
        key = str(raw_id).strip() if raw_id is not None else ''
        duplicate = bool(key and key in seen)
        duplicate_count += int(duplicate)
        if key:
            seen.add(key)
        (removed if duplicate and deduplicate else retained).append((number, row))
    grouped = defaultdict(list)
    for number, row in retained:
        group_value = row.get(category)
        group = str(group_value).strip() if group_value is not None else ''
        grouped[group or '(Uncategorized)'].append((number, row))
    if len(grouped) > 100:
        raise ValueError('More than 100 groups. Choose a category with fewer distinct values.')
    # Validate and aggregate from the retained records only.
    stats, findings = {}, []
    for group, records in sorted(grouped.items()):
        totals = defaultdict(Decimal)
        total, valid_amounts, invalid_amounts, invalid_dates = Decimal(0), 0, 0, 0
        for number, row in records:
            try:
                value = amount(row.get(money))
                total += value
                valid_amounts += 1
            except (InvalidOperation, ValueError):
                value = None
                invalid_amounts += 1
                findings.append([number, money, 'Invalid amount; retained but excluded from totals'])
            try:
                year = parse_date(row.get(date_column)).year
            except (ValueError, TypeError):
                year = None
                invalid_dates += 1
                findings.append([number, date_column, 'Invalid date; retained but excluded from annual totals'])
            if year is not None and value is not None:
                totals[year] += value
        stats[group] = dict(records=len(records), total=total, years=dict(totals),
                            valid_amounts=valid_amounts, invalid_amounts=invalid_amounts,
                            invalid_dates=invalid_dates)
    # A new run directory isolates outputs and avoids overwriting earlier reports.
    run = output / ('run_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    run.mkdir(parents=True, exist_ok=False)
    master = Workbook()
    clean = master.active
    clean.title = 'Cleaned Master'
    safe_append(clean, ['Source row'] + headers)
    for number, row in retained:
        safe_append(clean, [number] + [row[h] for h in headers])
    audit = master.create_sheet('Removed Duplicates')
    safe_append(audit, ['Source row'] + headers)
    for number, row in removed:
        safe_append(audit, [number] + [row[h] for h in headers])
    quality = master.create_sheet('Data Quality')
    safe_append(quality, ['Source row', 'Column', 'Finding'])
    for row in findings or [[None, None, 'No invalid amounts or dates found']]:
        safe_append(quality, row)
    for ws in master:
        format_sheet(ws)
    master.save(run / 'Cleaned Master.xlsx')
    groups = Workbook()
    index = groups.active
    index.title = 'Group Index'
    safe_append(index, ['Group', 'Worksheet', 'Records', 'Amount total', 'Invalid amounts', 'Invalid dates'])
    used = {'group index'}
    for group, records in sorted(grouped.items()):
        name = sheet_name(group, used)
        ws = groups.create_sheet(name)
        safe_append(ws, ['Source row'] + headers)
        for number, row in records:
            safe_append(ws, [number] + [row[h] for h in headers])
        st = stats[group]
        safe_append(index, [group, name, st['records'], float(st['total']), st['invalid_amounts'], st['invalid_dates']])
        index.cell(index.max_row, 4).number_format = '#,##0.00'
    for ws in groups:
        format_sheet(ws)
    groups.save(run / 'Grouped Records.xlsx')
    annual = Workbook()
    ws = annual.active
    ws.title = 'Yearly Comparison'
    safe_append(ws, ['Group', 'Year', 'Amount total', 'Change in amount', 'Year over year change'])
    all_years = [y for st in stats.values() for y in st['years']]
    for group, st in stats.items():
        if not all_years:
            break
        for year in range(min(all_years), max(all_years)+1):
            # Missing years remain unknown, never silently assumed to be zero.
            current, previous = st['years'].get(year), st['years'].get(year-1)
            delta = current - previous if current is not None and previous is not None else None
            rate = delta / previous if delta is not None and previous != 0 else None
            safe_append(ws, [group, year, float(current) if current is not None else None,
                             float(delta) if delta is not None else None, float(rate) if rate is not None else None])
            for col in (3, 4):
                ws.cell(ws.max_row, col).number_format = '#,##0.00;[Red](#,##0.00)'
            ws.cell(ws.max_row, 5).number_format = '0.0%'
    notes = annual.create_sheet('Method')
    for row in [['Method', 'Definition'], ['Annual total', 'Sum of valid amounts with a valid date in that year.'],
                ['Change', 'Current year minus immediately preceding calendar year.'],
                ['Percent change', '(Current minus previous) / previous; blank if previous is zero or missing.'],
                ['Missing years', 'Blank means no valid dated amounts; it does not establish zero activity.'],
                ['Units', 'Source units; use one currency per run. No conversion.'],
                ['Refresh', 'Static report. Rerun after changing source data.']]:
        safe_append(notes, row)
    for tab in annual:
        format_sheet(tab)
    annual.save(run / 'Yearly Comparison.xlsx')
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(.75)
    normal = doc.styles['Normal']
    normal.font.name, normal.font.size = 'Calibri', Pt(11)
    for style in ('Title', 'Heading 1', 'Heading 2'):
        doc.styles[style].font.color.rgb = RGBColor(0, 0, 0)
    doc.add_paragraph('Data Analysis Results', 'Title')
    doc.add_paragraph(f'This report summarizes {source.name}, grouped by {category}. '
                      'Use the accompanying workbooks to review the underlying records. '
                      'Amounts are in source units and reflect valid numeric values only.')
    doc.add_heading('Source and cleanup', 1)
    for text in [f'Original records: {len(original):,}', f'Repeated nonblank IDs: {duplicate_count:,}',
                 f'Duplicate records removed: {len(removed):,}', f'Retained records: {len(retained):,}',
                 f'Total amount: {sum(s["total"] for s in stats.values()):,.2f}']:
        doc.add_paragraph(text)
    doc.add_paragraph('Duplicate removal keeps the first record for each nonblank ID when enabled. '
                      'Blank IDs remain. Records are preserved as source values, without source formatting or formulas.')
    doc.add_heading('Group results', 1)
    for group, st in stats.items():
        doc.add_heading(group, 2)
        doc.add_paragraph(f'Records: {st["records"]:,}. Total amount: {st["total"]:,.2f}. '
                          f'Invalid amounts: {st["invalid_amounts"]:,}. Invalid dates: {st["invalid_dates"]:,}.')
    doc.add_heading('Interpreting the reports', 1)
    doc.add_paragraph('Each retained record belongs to one category group. Missing categories appear as Uncategorized. '
                      'Invalid amounts are excluded from totals. Invalid dates are excluded from annual totals, '
                      'so annual and overall amounts may differ. Missing annual observations and undefined percentage '
                      'changes are blank. This report does not infer missing activity or combine currencies.')
    doc.add_paragraph('Reports are static snapshots. Rerun the tool to refresh them. Review data-quality findings '
                      'and duplicate decisions before using results. The included sales demonstration uses fictional data.')
    doc.save(run / 'Results Summary.docx')
    return run, stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    for name in ('category', 'amount', 'date'):
        parser.add_argument('--'+name, required=True)
    parser.add_argument('--id')
    parser.add_argument('--sheet')
    parser.add_argument('--deduplicate', action='store_true')
    args = parser.parse_args()
    try:
        run, _ = build_bundle(args.input, args.output, args.category, args.amount, args.date,
                              args.id, args.deduplicate, args.sheet)
        print(f'Four reports created in: {run}')
    except (ValueError, KeyError, OSError) as error:
        parser.exit(1, f'Unable to complete report bundle: {error}\n')


if __name__ == '__main__':
    main()
