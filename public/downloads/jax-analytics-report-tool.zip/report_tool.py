"""Jax's Analytics: general spreadsheet reporting prototype.

Run without arguments for guided file selection, or use --help.
"""
import argparse
import calendar
import csv
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.chart import BarChart, Reference


def read_rows(path, sheet=None):
    if path.suffix.lower() == '.csv':
        with path.open(newline='', encoding='utf-8-sig') as stream:
            records = list(csv.reader(stream))
    elif path.suffix.lower() == '.xlsx':
        book = load_workbook(path, read_only=True, data_only=True)
        try:
            selected = book[sheet] if sheet else book[book.sheetnames[0]]
            records = list(selected.values)
        finally:
            book.close()
    else:
        raise ValueError('Choose a .xlsx or UTF-8 .csv file.')
    if not records:
        raise ValueError('The file is empty.')
    headers = [str(v).strip() if v is not None else '' for v in records[0]]
    if not all(headers) or len(set(headers)) != len(headers):
        raise ValueError('The first row must contain unique, nonblank column names.')
    rows = []
    for number, values in enumerate(records[1:], 2):
        if not any(v is not None and str(v).strip() for v in values):
            continue
        if len(values) > len(headers):
            raise ValueError(f'Row {number} has more values than headers.')
        rows.append((number, dict(zip(headers, list(values) + [None] * (len(headers)-len(values))))))
    return headers, rows


def amount(value):
    # Explicit decimal convention: 1,234.56 or $1,234.56. No currency conversion.
    text = str(value).strip().replace('$', '').replace(',', '')
    if text.startswith('(') and text.endswith(')'):
        text = '-' + text[1:-1]
    result = Decimal(text)
    if not result.is_finite():
        raise InvalidOperation()
    return result


def parse_date(value):
    if isinstance(value, (date, datetime)):
        return value
    return date.fromisoformat(str(value).strip())


def analyze(rows, category, money, date_column=None, id_column=None, deduplicate=False):
    categories, months = defaultdict(Decimal), defaultdict(Decimal)
    issues, prepared, seen = [], [], set()
    removed = invalid_amounts = invalid_dates = duplicate_ids = 0
    for number, row in rows:
        identifier = str(row.get(id_column) or '').strip() if id_column else ''
        duplicate = bool(identifier and identifier in seen)
        if id_column and not identifier:
            issues.append([number, id_column, 'Missing ID; record retained'])
        if duplicate:
            duplicate_ids += 1
            issues.append([number, id_column, 'Duplicate ID; removed' if deduplicate else 'Duplicate ID; retained'])
        if identifier:
            seen.add(identifier)
        if duplicate and deduplicate:
            removed += 1
            continue
        group = str(row.get(category) or '').strip()
        if not group:
            group = '(Uncategorized)'
            issues.append([number, category, 'Missing category; grouped as Uncategorized'])
        try:
            value = amount(row.get(money))
        except (InvalidOperation, ValueError):
            value = None
            invalid_amounts += 1
            issues.append([number, money, 'Missing/invalid amount; excluded from totals'])
        month = None
        if date_column:
            try:
                parsed = parse_date(row.get(date_column))
                month = parsed.strftime('%Y-%m')
            except (ValueError, TypeError):
                invalid_dates += 1
                issues.append([number, date_column, 'Missing/invalid date; excluded from monthly totals'])
        if value is not None:
            categories[group] += value
            if month:
                months[month] += value
        prepared.append([number, group, float(value) if value is not None else None, month])
    return dict(categories=categories, months=months, issues=issues, prepared=prepared,
                source=len(rows), removed=removed, invalid_amounts=invalid_amounts,
                invalid_dates=invalid_dates, duplicates=duplicate_ids)


def safe_append(sheet, values):
    sheet.append(values)
    # Source text is always text, including strings beginning with '='.
    for cell, value in zip(sheet[sheet.max_row], values):
        if isinstance(value, str):
            cell.data_type = 's'


def create_report(source, output, category, money, date_column=None, id_column=None,
                  sheet=None, deduplicate=False):
    headers, rows = read_rows(source, sheet)
    for name in (category, money, date_column, id_column):
        if name and name not in headers:
            raise ValueError(f'Column not found: {name}. Available: {", ".join(headers)}')
    if deduplicate and not id_column:
        raise ValueError('Choose an ID column before enabling duplicate removal.')
    result = analyze(rows, category, money, date_column, id_column, deduplicate)
    output.mkdir(parents=True, exist_ok=True)
    # Unique names; never overwrite the input or a previous report.
    target = output / f'report_{datetime.now():%Y%m%d_%H%M%S_%f}.xlsx'
    book = Workbook()
    summary = book.active
    summary.title = 'Summary'
    summary_rows = [
        ["Jax's Analytics | Data report", ''],
        ['Source file', source.name], ['Source worksheet', sheet or '(first worksheet / CSV)'],
        ['Report type', 'Static snapshot; rerun the tool to refresh'],
        ['Source records', result['source']], ['Duplicate IDs found', result['duplicates']],
        ['Duplicate records removed', result['removed']], ['Retained records', len(result['prepared'])],
        ['Invalid amounts excluded', result['invalid_amounts']],
        ['Invalid dates excluded from monthly view', result['invalid_dates']],
        ['Amount total (source units)', float(sum(result['categories'].values(), Decimal(0)))],
        ['Method', 'Retain all records unless duplicate removal is selected; first nonblank ID wins.'],
        ['Amount convention', 'One currency/unit per run; decimal point, optional commas/$/parentheses.'],
        ['Date convention', 'Excel dates or YYYY-MM-DD; no ambiguous date guessing.'],
        ['Category', 'Amount total (source units)'],
    ]
    for row in summary_rows:
        safe_append(summary, row)
    for group, total in sorted(result['categories'].items()):
        safe_append(summary, [group, float(total)])
    monthly = book.create_sheet('Monthly')
    safe_append(monthly, ['Month', 'Amount total (valid date and amount)'])
    if result['months']:
        first, last = min(result['months']), max(result['months'])
        year, month = map(int, first.split('-'))
        while f'{year:04}-{month:02}' <= last:
            key = f'{year:04}-{month:02}'
            safe_append(monthly, [key, float(result['months'].get(key, 0))])
            year, month = (year+1, 1) if month == 12 else (year, month+1)
        chart = BarChart()
        chart.title = 'Monthly totals'
        chart.add_data(Reference(monthly, min_col=2, min_row=1, max_row=monthly.max_row), titles_from_data=True)
        chart.set_categories(Reference(monthly, min_col=1, min_row=2, max_row=monthly.max_row))
        monthly.add_chart(chart, 'D2')
    else:
        safe_append(monthly, ['No valid dated amounts / no date selected', None])
    quality = book.create_sheet('Data Quality')
    safe_append(quality, ['Source row', 'Column', 'Finding'])
    for row in result['issues'] or [[None, None, 'No issues detected by the configured checks']]:
        safe_append(quality, row)
    prepared = book.create_sheet('Prepared Data')
    safe_append(prepared, ['Source row', 'Category', 'Amount', 'Month'])
    for row in result['prepared']:
        safe_append(prepared, row)
    raw = book.create_sheet('Source Data')
    safe_append(raw, ['Source row'] + headers)
    for number, row in rows:
        safe_append(raw, [number] + [row[h] for h in headers])
    for ws in book:
        ws.freeze_panes = 'A2'
        ws.sheet_view.showGridLines = False
        if ws != summary:
            ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.fill = PatternFill('solid', fgColor='152A40')
            cell.font = Font(color='FFFFFF', bold=True, size=12)
        ws.row_dimensions[1].height = 30
        for column in ws.columns:
            letter = column[0].column_letter
            ws.column_dimensions[letter].width = min(65, max(18, max(len(str(c.value or '')) for c in column)+2))
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical='top', wrap_text=True)
                if isinstance(cell.value, (int, float)):
                    cell.number_format = '#,##0.00;[Red](#,##0.00);–'
    summary.column_dimensions['A'].width = 44
    summary.column_dimensions['B'].width = 85
    for r in (12, 13, 14):
        summary.row_dimensions[r].height = 32
    for r in range(5, 11):
        summary.cell(r, 2).number_format = '0'
    book.save(target)
    return target, result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', nargs='?', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--sheet')
    parser.add_argument('--category')
    parser.add_argument('--amount')
    parser.add_argument('--date')
    parser.add_argument('--id')
    parser.add_argument('--deduplicate', action='store_true')
    args = parser.parse_args()
    try:
        if not args.input:
            from tkinter import Tk, filedialog
            root = Tk()
            root.withdraw()
            filename = filedialog.askopenfilename(title='Choose source data', filetypes=[('Excel or CSV', '*.xlsx *.csv')])
            root.destroy()
            if not filename:
                return
            args.input = Path(filename)
            if args.input.suffix.lower() == '.xlsx':
                book = load_workbook(args.input, read_only=True)
                print('Worksheets:', ', '.join(book.sheetnames))
                book.close()
                args.sheet = input('Worksheet name (blank = first): ').strip() or None
            headers, _ = read_rows(args.input, args.sheet)
            print('Columns:', ', '.join(headers))
            args.category = input('Category column: ').strip()
            args.amount = input('Amount column: ').strip()
            args.date = input('Date column (optional): ').strip() or None
            args.id = input('ID column (optional): ').strip() or None
            args.deduplicate = bool(args.id and input('Remove repeated IDs, keeping first? [y/N]: ').lower() == 'y')
            root = Tk()
            root.withdraw()
            directory = filedialog.askdirectory(title='Choose report output folder')
            root.destroy()
            if not directory:
                return
            args.output = Path(directory)
        if not args.category or not args.amount:
            raise ValueError('--category and --amount are required when using command-line input.')
        target, result = create_report(args.input, args.output or args.input.parent / 'reports',
                                      args.category, args.amount, args.date, args.id, args.sheet, args.deduplicate)
        print(f'Report saved: {target}\nData-quality findings: {len(result["issues"])}')
    except (ValueError, KeyError, OSError, InvalidOperation) as error:
        parser.exit(1, f'Unable to generate report: {error}\n')


if __name__ == '__main__':
    main()
